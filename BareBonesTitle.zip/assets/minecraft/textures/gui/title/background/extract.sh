#!/bin/bash
magick "$1" -crop 1440x1440+0+1440 l.png
magick "$1" -crop 1440x1440+1440+1440 f.png
magick "$1" -crop 1440x1440+2880+1440 r.png
magick "$1" -crop 1440x1440+4320+1440 b.png
magick "$1" -crop 1440x1440+1440+0 u.png
magick "$1" -crop 1440x1440+1440+2880 d.png
mv l.png panorama_3.png
mv f.png panorama_0.png
mv r.png panorama_1.png
mv b.png panorama_2.png
mv u.png panorama_4.png
mv d.png panorama_5.png
